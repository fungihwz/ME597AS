import launch
from launch_ros.actions import Node

def generate_launch_description():
    return launch.LaunchDescription([
        Node(
            package='task_2',
            executable='talker',
            name='talker'),
        Node(
            package='task_2',
            executable='listener',
            name='listener'),
  ])
