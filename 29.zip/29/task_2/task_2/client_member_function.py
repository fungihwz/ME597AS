import sys

from task_2_interfaces.srv import JointState
import rclpy
from rclpy.node import Node


class MinimalClientAsync(Node):

    def __init__(self):
        super().__init__('minimal_client_async')
        self.cli = self.create_client(JointState, 'joint_service')
        while not self.cli.wait_for_service(timeout_sec=1.0):
            self.get_logger().info('service not available, waiting again...')
        self.req = JointState.Request()

    def send_request(self):
        self.req.x = float(sys.argv[1])
        self.req.y = float(sys.argv[2])
        self.req.z = float(sys.argv[3])

        return self.cli.call_async(self.req)


def main():
    rclpy.init()

    minimal_client = MinimalClientAsync()
    future = minimal_client.send_request()
    rclpy.spin_until_future_complete(minimal_client, future)
    response = future.result()
    minimal_client.get_logger().info(
        'Result: sum is %f + %f + %f. Response: sum positive? %s' %
        (minimal_client.req.x, minimal_client.req.y, minimal_client.req.z, str(response.valid))
        
    )
    minimal_client.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()