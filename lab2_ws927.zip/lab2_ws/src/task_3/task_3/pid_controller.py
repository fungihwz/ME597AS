import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from sensor_msgs.msg import LaserScan
from std_msgs.msg import Float32
import numpy as np

#from task_2_interfaces.msg import JointData  
#from std_msgs.msg import String

class PIDControllerNode(Node):

    def __init__(self):
        super().__init__('pid_speed_controller')

        self.target_distance = 0.35
        self.forward_distance = 0.0

        self.kp = 1.2
        self.ki = 0.0
        self.kd = 0.01

        self.prevError = 0.0
        self.integral = 0.0
        self.last_time = self.get_clock().now()
        
        self.vel_publisher = self.create_publisher(Twist, 'cmd_vel', 10)
        self.timer_period = 0.1  # seconds
        self.timer = self.create_timer(self.timer_period, self.control_loop)
        #self.i = 0
        
        self.subscription = self.create_subscription(
            LaserScan,
            '/scan',
            self.lidar_callback,
            10)
    

    def lidar_callback(self, msg: LaserScan):
        self.forward_distance = msg.ranges[0] #figure shows?


    def control_loop(self):
        error = self.forward_distance - self.target_distance

        #current_time = self.get_clock().now()
        #delta_time = (current_time - self.last_time).nanoseconds / 1e9

        p = self.kp * error
        self.integral += error * self.timer_period
        i = self.ki * self.integral
        derivative = (error - self.prevError) / self.timer_period
        d = self.kd * derivative
        control_output = p + i + d

        #constrain
        max_vel = 0.15
        velocity = np.clip(control_output, 0, max_vel)

        cmd_vel_msg = Twist()
        cmd_vel_msg.linear.x = velocity
        cmd_vel_msg.angular.z = 0.0
        self.vel_publisher.publish(cmd_vel_msg)
        
        self.prevError = error
        #self.last_time = current_time
        #self.get_logger().info('ctrlinputs: "%f"' % error)
        #self.get_logger().info('ctrloutputs: "%f"' % control_output)
        self.get_logger().info('I see: "%f" meter from wall ' % self.forward_distance)
        



def main(args=None):
    rclpy.init(args=args)

    pid_speed_controller = PIDControllerNode()

    rclpy.spin(pid_speed_controller)

    # Destroy the node explicitly
    # (optional - otherwise it will be done automatically
    # when the garbage collector destroys the node object)
    pid_speed_controller.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()

