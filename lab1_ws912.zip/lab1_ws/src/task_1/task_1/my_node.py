def main():
    print('Hi from task_1.')


if __name__ == '__main__':
    main()
