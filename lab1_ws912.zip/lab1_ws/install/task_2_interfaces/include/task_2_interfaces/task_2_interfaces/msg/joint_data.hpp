// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef TASK_2_INTERFACES__MSG__JOINT_DATA_HPP_
#define TASK_2_INTERFACES__MSG__JOINT_DATA_HPP_

#include "task_2_interfaces/msg/detail/joint_data__struct.hpp"
#include "task_2_interfaces/msg/detail/joint_data__builder.hpp"
#include "task_2_interfaces/msg/detail/joint_data__traits.hpp"

#endif  // TASK_2_INTERFACES__MSG__JOINT_DATA_HPP_
