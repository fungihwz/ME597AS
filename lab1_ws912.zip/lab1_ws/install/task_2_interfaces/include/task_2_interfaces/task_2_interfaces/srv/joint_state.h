// generated from rosidl_generator_c/resource/idl.h.em
// with input from task_2_interfaces:srv/JointState.idl
// generated code does not contain a copyright notice

#ifndef TASK_2_INTERFACES__SRV__JOINT_STATE_H_
#define TASK_2_INTERFACES__SRV__JOINT_STATE_H_

#include "task_2_interfaces/srv/detail/joint_state__struct.h"
#include "task_2_interfaces/srv/detail/joint_state__functions.h"
#include "task_2_interfaces/srv/detail/joint_state__type_support.h"

#endif  // TASK_2_INTERFACES__SRV__JOINT_STATE_H_
