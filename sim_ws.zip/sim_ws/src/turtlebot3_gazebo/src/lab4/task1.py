#!/usr/bin/env python3


# Import other python packages that you think necessary
import rclpy
from rclpy.node import Node
import random
import math
import numpy as np

from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry
from sensor_msgs.msg import LaserScan

class Task1(Node):
    """
    Environment mapping task using RRT.
    """
    def __init__(self):
        # PID parameters
        self.k_p = 0.8
        self.k_i = 0.000#1
        self.k_d = 0.0#1
        self.target_distance = 0.6  # Desired distance from the wall
        self.linear_speed = 0.2  # Constant forward speed
        self.dt = 0.1
        # Variables for PID control
        self.prev_error = 0.0
        self.integral = 0.0
        self.errors = []
        # Laser scan data storage
        self.laser_data = None
        
        super().__init__('task1_node')
        self.timer = self.create_timer(self.dt, self.control_loop)
        self.cmd_vel_pub = self.create_publisher(Twist, '/cmd_vel', 10)
        self.scan_sub = self.create_subscription(LaserScan, '/scan', self.lidar_cb, 10)
        # self.odom_sub = self.create_subscription(Odometry, '/odom', self.odom_cb, 10)
        # self.current_position = None
        # self.scan_data = None
        # self.tree = []  # RRT tree as a list of nodes
        # self.explored_area = set()  # Track explored grid cells
        # self.grid_resolution = 0.1  # Resolution for grid coverage


        self.get_logger().info("Wall Following Node Initialized!")

    def lidar_cb(self, msg):
        """
        Callback function to update laser scan data.
        """
        self.laser_data = msg

    def get_distance(self, start_idx, end_idx):
        """
        Extracts the minimum distance from a range of indices in laser scan data.
        """
        if not self.laser_data:
            return float('inf')
        valid_ranges = [
            r for r in self.laser_data.ranges[start_idx:end_idx] if not math.isinf(r)
        ]
        return min(valid_ranges) if valid_ranges else float('inf')


    def control_loop(self):
        """
        Main control loop for wall-following behavior.
        """
        if not self.laser_data:
            return  # Wait for laser data to be available

        # Get distances
        front_distance = self.get_distance(350, 359)  # Front distance
        right_distance = self.get_distance(310, 320)  # Front-Right distance

        # If too close to a wall in front, rotate
        if front_distance < 1.0: #self.target_distance:
            twist = Twist()
            twist.linear.x = 0.0
            twist.angular.z = 0.5  # Rotate left to avoid collision
            self.cmd_vel_pub.publish(twist)
            self.get_logger().info(f"Too close to front wall: {front_distance:.2f}")
            return

        # PID control for right-side wall-following
        error = (self.target_distance - right_distance)
        # self.errors.append(error)
        # self.integral += error * self.dt
        # derivative = (error - self.prev_error) / self.dt

        # Compute PID output for angular velocity
        angular_z = (
            self.k_p * error #+ self.k_i * self.integral + self.k_d * derivative
        )
        self.prev_error = error

        # Publish twist message
        twist = Twist()
        twist.linear.x = self.linear_speed
        twist.angular.z = np.clip(angular_z, -0.5, 0.3)
        self.cmd_vel_pub.publish(twist)

        # Logging
        self.get_logger().info(
            f"ref-wall dist: {error:.2f}, yaw rate: {angular_z:.2f}, Right wall Distance: {right_distance:.2f}, front: {front_distance:.2f}"
        )


def main(args=None):
    rclpy.init(args=args)
    task1 = Task1()
    try:
        rclpy.spin(task1)
    except KeyboardInterrupt:
        pass
    finally:
        task1.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
