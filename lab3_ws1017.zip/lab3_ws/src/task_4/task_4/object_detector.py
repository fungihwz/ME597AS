import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image
from vision_msgs.msg import BoundingBox2D
from cv_bridge import CvBridge
import cv2
import numpy as np

class ObjectDetector(Node):
    def __init__(self):
        super().__init__('object_detector')
        self.subscription = self.create_subscription(
            Image,
            '/video_data',
            self.listener_callback,
            10)
        self.publisher_ = self.create_publisher(BoundingBox2D, '/bbox', 10)
        self.bridge = CvBridge()
        self.get_logger().info("Object Detector Initialized")
        
    def listener_callback(self, msg):
        # Convert ROS Image message to OpenCV format
        frame = self.bridge.imgmsg_to_cv2(msg, desired_encoding='bgr8')
        
        # Convert the image to HSV color space for color filtering
        hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
        # Define lower and upper bounds for the color red in HSV
        lower_red = np.array([0, 100, 100])
        upper_red = np.array([10, 255, 255])

        # Create a mask for red regions
        mask = cv2.inRange(hsv, lower_red, upper_red)
        red_filtered = cv2.bitwise_and(frame, frame, mask=mask)
        
        # Convert the filtered image to grayscale
        gray = cv2.cvtColor(red_filtered, cv2.COLOR_BGR2GRAY)
        
        # Apply binary thresholding
        _, thresh = cv2.threshold(gray, 1, 255, cv2.THRESH_BINARY)
  
        
        # Find contours in the binary image
        contours, _ = cv2.findContours(thresh, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
        filt_contours = []
        for contour in contours:
            # Approximate the contour to reduce the number of vertices
            epsilon = 0.02 * cv2.arcLength(contour, True)
            approx = cv2.approxPolyDP(contour, epsilon, True)

            # Check if the contour has 3 vertices (i.e., it's a triangle)
            if len(approx) == 3 and cv2.contourArea(contour) > 2500:
                # Draw the contour in green
                #filt_contours.append(contour)
                cv2.drawContours(frame, [approx], 0, (0, 255, 0), 3)
                M = cv2.moments(contour)#filt_contours[0])
                cx = int(M['m10']/M['m00'])
                cy = int(M['m01']/M['m00'])
                
                centroid = cv2.circle(frame, (cx,cy), 5, (255,0,0), -1)
                # Calculate the bounding box of the triangle
                x, y, w, h = cv2.boundingRect(contour)
                # Draw the bounding box around the triangle
                cv2.rectangle(frame, (x, y), (x + w, y + h), (255, 0, 0), 2)
                
                
                # Print object details
                self.get_logger().info(f"Centroid (x, y): ({cx}, {cy}), Width: {w}, Height: {h}")
                
                # Publish the bounding box information
                bbox_msg = BoundingBox2D()
                bbox_msg.center.position.x = float(cx)
                bbox_msg.center.position.y = float(cy)
                bbox_msg.size_x = float(w)
                bbox_msg.size_y = float(h)
                self.publisher_.publish(bbox_msg)
            

        
        # Display the frame with the bounding box
        cv2.imshow("Object Detection", frame)
        cv2.waitKey(1)

def main(args=None):
    rclpy.init(args=args)
    object_detector = ObjectDetector()
    
    rclpy.spin(object_detector)

    # Cleanup
    object_detector.destroy_node()
    rclpy.shutdown()
    cv2.destroyAllWindows()

if __name__ == '__main__':
    main()