import launch
from launch_ros.actions import Node

def generate_launch_description():
    return launch.LaunchDescription([
        Node(
            package='task_4',
            executable='image_publisher',
            name='image_publisher'),
        Node(
            package='task_4',
            executable='object_detector',
            name='object_detector'),

  ])
