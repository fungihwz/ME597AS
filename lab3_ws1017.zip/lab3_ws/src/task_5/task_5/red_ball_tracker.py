import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image
from vision_msgs.msg import BoundingBox2D
from cv_bridge import CvBridge
from geometry_msgs.msg import Twist
import cv2
import numpy as np

class RedBallTracker(Node):
    def __init__(self):
        super().__init__('red_ball_tracker')
        self.subscription = self.create_subscription(
            Image,
            '/camera/image_raw',  # Replace with actual topic for your robot's camera
            self.image_callback,
            10)
        self.publisher_ = self.create_publisher(Twist, '/cmd_vel', 10)
        self.bridge = CvBridge()
        self.center_x = None  # Center x-coordinate of detected ball
        self.ball_radius = None  # Radius of detected ball
        self.in_search_mode = True  # Initial mode is search mode

        # Constants for movement thresholds and control
        self.frame_center = None
        self.near_distance = 80.0  # Radius threshold to consider "very close"
        self.far_distance = 50.0 # Radius threshold to consider "far away"
        self.linear_speed = 0.2  # Speed to approach or move away from the ball
        self.angular_speed = 0.15  # Speed to turn towards the ball

        self.get_logger().info("Red Ball Tracker Initialized")

    def image_callback(self, msg):
        # Convert the ROS Image message to OpenCV format
        frame = self.bridge.imgmsg_to_cv2(msg, desired_encoding='bgr8')
        self.frame_center = frame.shape[1] // 2  # Horizontal center of the frame

        # Convert to HSV and apply a mask for red color
        hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
        lower_red = np.array([0, 100, 100])
        upper_red = np.array([10, 255, 255])
        mask = cv2.inRange(hsv, lower_red, upper_red)
        
        # Use HoughCircles to detect circular shapes in the masked image
        circles = cv2.HoughCircles(mask, cv2.HOUGH_GRADIENT, dp=1.2, minDist=30,
                                   param1=50, param2=30, minRadius=5, maxRadius=100)

        if circles is not None:
            # Get the coordinates and radius of the largest detected circle
            circles = np.round(circles[0, :]).astype("int")
            x, y, radius = circles[0]

            # Draw the detected circle and centroid
            cv2.circle(frame, (x, y), radius, (0, 255, 0), 2)
            cv2.circle(frame, (x, y), 5, (0, 0, 255), -1)

            # Update detected ball position
            self.center_x = x
            self.ball_radius = radius
            self.in_search_mode = False  # Exit search mode and start tracking

            # Control the robot's movement
            self.track_ball()

        else:
            # No ball detected, stop the robot or enter search mode
            self.enter_search_mode()

        # Display the frame for debugging purposes
        cv2.imshow("Red Ball Tracking", frame)
        cv2.waitKey(1)

    def track_ball(self):
        twist = Twist()

        # Turn to keep the ball centered in the frame
        if self.center_x < self.frame_center - 10:  # Ball is to the left
            twist.angular.z = self.angular_speed
        elif self.center_x > self.frame_center + 10:  # Ball is to the right
            twist.angular.z = -self.angular_speed
        else:
            twist.angular.z = 0.0  # Ball is centered horizontally

        # Move towards or away from the ball based on its size (distance)
        if self.ball_radius < self.far_distance:
            twist.linear.x = self.linear_speed  # Move towards the ball
        elif self.ball_radius > self.near_distance:
            twist.linear.x = -self.linear_speed  # Move away from the ball
        else:
            twist.linear.x = 0.0  # Stop if the ball is at a desired distance

        # Publish the movement command
        self.publisher_.publish(twist)

    def enter_search_mode(self):
        # If in search mode, rotate counterclockwise
        if self.in_search_mode:
            twist = Twist()
            twist.angular.z = self.angular_speed  # Spin counterclockwise
            self.publisher_.publish(twist)
        else:
            # If no ball detected but search mode not active, stop the robot
            self.stop_robot()
            self.in_search_mode = True  # Re-enter search mode

    def stop_robot(self):
        # Stop all motion by publishing zero velocities
        twist = Twist()
        twist.linear.x = 0.0
        twist.angular.z = 0.0
        self.publisher_.publish(twist)

def main(args=None):
    rclpy.init(args=args)
    red_ball_tracker = RedBallTracker()
    rclpy.spin(red_ball_tracker)

    # Clean up on shutdown
    red_ball_tracker.destroy_node()
    rclpy.shutdown()
    cv2.destroyAllWindows()

if __name__ == '__main__':
    main()